package test;



import static org.junit.Assert.*;

import java.sql.Connection;
import java.util.List;

import org.junit.Test;

import bean.Admin;
import bean.AdminRole;
import bean.Category;
import bean.PageBean;
import bean.SmallCategory;
import bean.User;
import dao.AdminDao;
import dao.CategoryDao;
import dao.SmallCategoryDao;
import dao.UserDao;
import dao.impl.AdminDaoImpl;
import dao.impl.CategoryDaoImpl;
import dao.impl.SmallCategoryDaoImpl;
import dao.impl.UserListDaoImpl;
import utils.PoolUtil;

public class MyTest {
	@Test
	public void testDruid() throws Exception {
		Connection con = PoolUtil.getCon();
		System.out.println(con);
	}
	@Test
	public void testAdminDaoLogin() throws Exception {
		AdminDao ad = new AdminDaoImpl();
		Admin login = new Admin();
		login.setAname("admin");
		login.setApassword("123");
		AdminRole adminRole = ad.login(login);
		System.out.println(adminRole);
	}
	@Test
	public void testUserListDao() throws Exception {
		UserDao ud = new UserListDaoImpl();
		List<User> userlist = ud.userlist();
		System.out.println(userlist);
	}
	@Test//测试出错
	public void queryAllTest() throws Exception {
		UserDao ud = new UserListDaoImpl();
		
		System.out.println(ud.queryAll());
	}
	@Test
	public void testPageUser() throws Exception {
		UserDao ud = new UserListDaoImpl();
		PageBean<User> pagebean = new PageBean<>();
		List<User> querypagelimit = ud.querypagelimit(pagebean);
		for (User user : querypagelimit) {
			System.out.println(user);
		}
	}
	@Test
	public void testCategory() throws Exception {
		CategoryDao cd = new CategoryDaoImpl();
		List<Category> queryAll = cd.queryAll();
		for (Category category : queryAll) {
			System.out.println(category);
		}
	}
	@Test
	public void testSmallCategory() throws Exception {
		SmallCategoryDao cd = new SmallCategoryDaoImpl();
		List<SmallCategory> querysmallbycid = cd.querysmallbycid(2001);
		for (SmallCategory smallCategory : querysmallbycid) {
			System.out.println(smallCategory);
		}
	}
}
