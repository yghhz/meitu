package utils;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class BcryptUtil {
	
	public static String getBcryptPSW(String password) {
		
		BCryptPasswordEncoder bpe = new BCryptPasswordEncoder();
		String encode = bpe.encode(password);
		return encode;
		
	}
	
	public static boolean match(String password,String encode){
		BCryptPasswordEncoder bpe = new BCryptPasswordEncoder();
		return bpe.matches(password, encode);
	}
	
}
