package utils;


import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import com.alibaba.druid.pool.DruidDataSourceFactory;

/**
 * 连接池工具类
 * @author wang7
 *
 */
public class PoolUtil {
	
	private static DataSource dataSource;
	static {
		InputStream is = PoolUtil.class.getClassLoader().getResourceAsStream("druid.properties");
		Properties prop = new Properties();
		try {
			prop.load(is);
			dataSource = DruidDataSourceFactory.createDataSource(prop);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	/**提供公共访问获取连接池的方法
	 * @return连接池对象
	 */
	public static DataSource getDataSource() {
		return dataSource;
	}
	
	/**提供公共访问获取连接的方法
	 * @return连接对象
	 */
	public static Connection getCon() {
		try {
			return dataSource.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
}
