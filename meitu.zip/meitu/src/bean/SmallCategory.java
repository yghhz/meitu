package bean;

public class SmallCategory {
	private Integer sid;
	private String sname;
	private Integer cid;
	private String ciddisplay;
	public String getCiddisplay() {
		return ciddisplay;
	}
	public void setCiddisplay(String ciddisplay) {
		this.ciddisplay = ciddisplay;
	}
	public Integer getSid() {
		return sid;
	}
	public void setSid(Integer sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public Integer getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
		if(cid == 1) {
			this.setCiddisplay("汽车");
		}else if(cid == 2) {
			this.setCiddisplay("风景");
		}
	}
	@Override
	public String toString() {
		return "SmallCategory [sid=" + sid + ", sname=" + sname + ", cid=" + cid + "]";
	}
	
}
