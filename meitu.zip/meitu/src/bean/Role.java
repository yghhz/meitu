package bean;

public class Role {
	private Integer rid;
	private String rname;
	private String rdisplay;
	public Integer getRid() {
		return rid;
	}
	public void setRid(Integer rid) {
		this.rid = rid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getRdisplay() {
		return rdisplay;
	}
	public void setRdisplay(String rdisplay) {
		this.rdisplay = rdisplay;
	}
	public Role() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Role [rid=" + rid + ", rname=" + rname + ", rdisplay=" + rdisplay + "]";
	}
	
}
