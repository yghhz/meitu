package bean;

public class Ustate {

	private int ustate;
	private String ustatedisplay;
	public int getUstate() {
		return ustate;
	}
	public void setUstate(int ustate) {
		this.ustate = ustate;
	}
	public String getUstatedisplay() {
		return ustatedisplay;
	}
	public void setUstatedisplay(String ustatedisplay) {
		this.ustatedisplay = ustatedisplay;
	}
	@Override
	public String toString() {
		return "Ustate [ustate=" + ustate + ", ustatedisplay=" + ustatedisplay + "]";
	}
	
}
