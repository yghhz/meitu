package bean;

public class AdminRole extends Admin{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String rname;
	private String rdisplay;
	
	public AdminRole() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getRdisplay() {
		return rdisplay;
	}
	public void setRdisplay(String rdisplay) {
		this.rdisplay = rdisplay;
	}
	@Override
	public String toString() {
		return "AdminRole [rname=" + rname + ", rdisplay=" + rdisplay + "]"+super.toString();
	}
	
}
