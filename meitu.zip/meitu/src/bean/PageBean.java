package bean;

import java.util.List;


/**通用的分页bean
 * @author wang7
 *查询不同的数据时，对应封装为T类型
 * @param <T>
 */
public class PageBean<T> {
	private int pagesize = 3; //页面存放数据的条数
	private int nowpage = 1; //当前页的页码 ----从页面来
	private int total; //查询出的总记录数 ----从数据库查询
	private int lastpage; //末尾页的页码 -----有了total能算出
	private List<T> datas; //每页里数据对象的聚合 ----从数据库查询
	
	private int first;//1显示2不显示 ----知道nowpage是几 如果是1不显示
	private int last;//1显示2不显示 ---- 知道nowpage是几 如果是最后一页不显示
	private int previous;//1显示2不显示 ----知道nowpage是几 如果是1不显示
	private int next;//1显示2不显示 知道nowpage是几 如果是最后一页不显示
	
	public PageBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPagesize() {
		return pagesize;
	}

	public void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}

	public int getNowpage() {
		return nowpage;
	}

	public void setNowpage(int nowpage) {
		this.nowpage = nowpage;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
		this.lastpage = total%pagesize==0?total/pagesize:total/pagesize+1;
		this.first = this.nowpage>1?1:2;
		this.last = this.nowpage<this.lastpage?1:2;
		this.previous = this.nowpage>1?1:2;
		this.next = this.nowpage<this.lastpage?1:2;
	}

	public int getLastpage() {
		return lastpage;
	}

	public void setLastpage(int lastpage) {
		this.lastpage = lastpage;
	}

	public List<T> getDatas() {
		return datas;
	}

	public void setDatas(List<T> datas) {
		this.datas = datas;
	}

	public int getFirst() {
		return first;
	}

	public void setFirst(int first) {
		this.first = first;
	}

	public int getLast() {
		return last;
	}

	public void setLast(int last) {
		this.last = last;
	}

	public int getPrevious() {
		return previous;
	}

	public void setPrevious(int previous) {
		this.previous = previous;
	}

	public int getNext() {
		return next;
	}

	public void setNext(int next) {
		this.next = next;
	}

	@Override
	public String toString() {
		return "PageBean [pagesize=" + pagesize + ", nowpage=" + nowpage + ", total=" + total + ", lastpage=" + lastpage
				+ ", datas=" + datas + ", first=" + first + ", last=" + last + ", previous=" + previous + ", next="
				+ next + "]";
	}
	
	
}
