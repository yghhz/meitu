package bean;

public class User {
	private Integer uid;
	private String uname;
	private String upassword;
	private String unick;
	private Integer usex;
	private String usexdisplay;
	private String ubirthday;
	private String uemail;
	private String uphoto;
	private Integer ustate;
	private String ustatedisplay;
	
	public String getUsexdisplay() {
		return usexdisplay;
	}
	public void setUsexdisplay(String usexdisplay) {
		this.usexdisplay = usexdisplay;
	}
	public String getUstatedisplay() {
		return ustatedisplay;
	}
	public void setUstatedisplay(String ustatedisplay) {
		this.ustatedisplay = ustatedisplay;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpassword() {
		return upassword;
	}
	public void setUpassword(String upassword) {
		this.upassword = upassword;
	}
	public String getUnick() {
		return unick;
	}
	public void setUnick(String unick) {
		this.unick = unick;
	}
	public Integer getUsex() {
		return usex;
	}
	public void setUsex(Integer usex) {
		this.usex = usex;
		if(usex == 1) {
			this.setUsexdisplay("女");
		}else {
			this.setUsexdisplay("男");
		}
	}
	public String getUbirthday() {
		return ubirthday;
	}
	public void setUbirthday(String ubirthday) {
		this.ubirthday = ubirthday;
	}
	public String getUemail() {
		return uemail;
	}
	public void setUemail(String uemail) {
		this.uemail = uemail;
	}
	public String getUphoto() {
		return uphoto;
	}
	public void setUphoto(String uphoto) {
		this.uphoto = uphoto;
	}
	public Integer getUstate() {
		return ustate;
	}
	public void setUstate(Integer ustate) {
		this.ustate = ustate;
		if(ustate == 1) {
			this.setUstatedisplay("可用");
		}else if(ustate == 2){
			this.setUstatedisplay("注销");
		}else {
			this.setUstatedisplay("冻结");
		}
	}
	@Override
	public String toString() {
		return "User [uid=" + uid + ", uname=" + uname + ", upassword=" + upassword + ", unick=" + unick + ", usex="
				+ usex + ", ubirthday=" + ubirthday + ", uemail=" + uemail + ", uphoto=" + uphoto + ", ustate=" + ustate
				+ "]";
	}
	
}
