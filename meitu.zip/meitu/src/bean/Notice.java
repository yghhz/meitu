package bean;

import java.util.Date;

public class Notice {

	private Integer nid;
	private String nname;
	private String ncontent;
	private Date ntime;
	private Integer nstate;
	private String nstatedisplay;
	public Notice() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getNid() {
		return nid;
	}
	public void setNid(Integer nid) {
		this.nid = nid;
	}
	public String getNname() {
		return nname;
	}
	public void setNname(String nname) {
		this.nname = nname;
	}
	public String getNcontent() {
		return ncontent;
	}
	public void setNcontent(String ncontent) {
		this.ncontent = ncontent;
	}
	public Date getNtime() {
		return ntime;
	}
	public void setNtime(Date ntime) {
		this.ntime = ntime;
	}
	public Integer getNstate() {
		return nstate;
	}
	public void setNstate(Integer nstate) {
		this.nstate = nstate;
		if(nstate == 1) {
			this.setNstatedisplay("可用");
		}else {
			this.setNstatedisplay("不可用");
		}
	}
	@Override
	public String toString() {
		return "Notice [nid=" + nid + ", nname=" + nname + ", ncontent=" + ncontent + ", ntime=" + ntime + ", nstate="
				+ nstate + "]";
	}
	public String getNstatedisplay() {
		return nstatedisplay;
	}
	public void setNstatedisplay(String nstatedisplay) {
		this.nstatedisplay = nstatedisplay;
	}
	
}
