package bean;

public class Picture {
	
	private int pid;
	private String pname;
	private String ppath;
	private int sid;
	private int praise;
	private String pdisplay;
	private int uid;
	private String psimplyname;
	
	public String getPsimplyname() {
		return psimplyname;
	}

	public void setPsimplyname(String psimplyname) {
		this.psimplyname = psimplyname;
	}

	public Picture() {
		
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPpath() {
		return ppath;
	}

	public void setPpath(String ppath) {
		this.ppath = ppath;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public int getPraise() {
		return praise;
	}

	public void setPraise(int praise) {
		this.praise = praise;
	}

	public String getPdisplay() {
		return pdisplay;
	}

	public void setPdisplay(String pdisplay) {
		this.pdisplay = pdisplay;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	@Override
	public String toString() {
		return "Pciture [pid=" + pid + ", pname=" + pname + ", ppath=" + ppath + ", sid=" + sid + ", praise=" + praise
				+ ", pdisplay=" + pdisplay + ", uid=" + uid + "]";
	}
	
	
	
}
