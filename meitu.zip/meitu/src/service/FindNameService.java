package service;

public interface FindNameService {

	boolean finaname(String uname);


}
