package service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.PageBean;
import bean.User;
import bean.Ustate;

public interface UserService {

	List<User> userlist();

	PageBean<User> userlistpage(PageBean<User> pagebean);

	void register(User user);

	List<User> userlogin(String username, String password);

	void changeuserinfo(User user);

	User flushchangeuserinfo(User user);

	void userinfo(HttpServletRequest request, HttpServletResponse response);

	void userclose(User user);

	List<Ustate> queryustate();

	void changeustate(int uid, int ustate);

	User querynewstate(int uid);


}
