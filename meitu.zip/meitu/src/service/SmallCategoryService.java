package service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.SmallCategory;


public interface SmallCategoryService {

	List<SmallCategory> querysmallbycid(int cid);

	void smallcategorymanage(HttpServletRequest request, HttpServletResponse response);

	void changesmallcate(int sid, String sname);

	SmallCategory querynewsmallcate(int sid);

	SmallCategory insertsmallcate(int cid);

	SmallCategory querydefalutsmall(int cid);

	void deletesmallcate(int sid);

}
