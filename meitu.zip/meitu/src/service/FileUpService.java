package service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Picture;
import bean.User;

public interface FileUpService {

	void fileuppage(HttpServletRequest request, HttpServletResponse response);

	User headportrait(String newFilename, User user);

	void photofileup(HttpServletRequest request, HttpServletResponse response);

	int querysid(String smallcategory);

	Picture insertpicture(Picture picture, int sid, String pname, String ppath, int uid, String picturedisplay, int praise, String name);

	void picturelist(HttpServletRequest request, HttpServletResponse response);

	List<Picture> querypciture(Integer uid);

}
