package service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Category;

public interface CategoryService {

	List<Category> queryAll();

	void categorymanage(HttpServletRequest request, HttpServletResponse response);

	void changecategory(int cid,String cname);

	Category querycategory(int cid);

	void insertcategory(Category insertcate);

	Category querynewcate();

	void deletecategory(int cid);

	void insertdefaultsmallcate(Integer cid);

}
