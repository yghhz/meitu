package service;

import java.util.List;

import bean.Picture;

public interface PictureService {

	List<Picture> querypictures(String category,String smallcategory, String usernamepicture, String picturedisplay);

	Picture querysinglepicture(int pid);

	void changepraise(int pid, int praise);

	List<Picture> picturerankinglist();

}
