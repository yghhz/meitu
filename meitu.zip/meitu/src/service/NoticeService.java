package service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Notice;

public interface NoticeService {

	List<Notice> noticelist();

	void usernoticelist(HttpServletRequest request, HttpServletResponse response);

	List<Notice> querynotices();

	void changenotice(int nid, String ncontent, String nstatus, String nname);

	void insertnotice(Notice notice);

	void deletenotice(int nid);

	List<Notice> queryablenotice();

}
