package service.impl;

import dao.FindNameDao;
import dao.impl.FindNameDaoImpl;
import service.FindNameService;

public class FindNameServiceImpl implements FindNameService{
	
	FindNameDao fnd= new FindNameDaoImpl();
	@Override
	public boolean finaname(String uname) {
		// TODO Auto-generated method stub
		return fnd.finaname(uname);
	}

}
