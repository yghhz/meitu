package service.impl;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Category;
import dao.CategoryDao;
import dao.impl.CategoryDaoImpl;
import service.CategoryService;

public class CategoryServiceImpl implements CategoryService {
	CategoryDao cd = new CategoryDaoImpl();
	@Override
	public List<Category> queryAll() {
		// TODO Auto-generated method stub
		return cd.queryAll();
	}
	@Override
	public void categorymanage(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.getRequestDispatcher("/WEB-INF/admin/categorymanage.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void changecategory(int cid,String cname) {
		cd.changecategory(cid,cname);
	}
	@Override
	public Category querycategory(int cid) {
		// TODO Auto-generated method stub
		return cd.querycategory(cid);
	}
	@Override
	public void insertcategory(Category insertcate) {
		insertcate.setCname("默认分类名");
		cd.insertcategory(insertcate);
	}
	@Override
	public Category querynewcate() {
		// TODO Auto-generated method stub
		return cd.querynewcate();
	}
	@Override
	public void deletecategory(int cid) {
		// TODO Auto-generated method stub
		cd.deletecategory(cid);
	}
	@Override
	public void insertdefaultsmallcate(Integer cid) {
		cd.insertdefaultsmallcate(cid);
	}

}
