package service.impl;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Picture;
import bean.User;
import dao.FileUpDao;
import dao.impl.FileUpDaoImpl;
import service.FileUpService;

public class FileUpServiceImpl implements FileUpService {
	
	FileUpDao fud = new FileUpDaoImpl();
	
	@Override
	public void fileuppage(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		try {
			request.getRequestDispatcher("/WEB-INF/user/photo.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public User headportrait(String newFilename, User user) {
		// TODO Auto-generated method stub
		return fud.headportrait(newFilename,user);
	}

	@Override
	public void photofileup(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		try {
			request.getRequestDispatcher("/WEB-INF/picture/photofileup.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public int querysid(String smallcategory) {
		// TODO Auto-generated method stub
		return fud.querysid(smallcategory);
	}

	@Override
	public Picture insertpicture(Picture picture, int sid, String pname, String ppath, int uid,String picturedisplay,int praise,String name) {
		
		// TODO Auto-generated method stub
		picture.setPsimplyname(name);
		picture.setPname(pname);
		picture.setPpath(ppath);
		picture.setSid(sid);
		picture.setUid(uid);
		picture.setPdisplay(picturedisplay);
		picture.setPraise(praise);
		return fud.insertpicture(picture);
	}

	@Override
	public void picturelist(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		try {
			request.getRequestDispatcher("/WEB-INF/picture/picturelist.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Picture> querypciture(Integer uid) {
		// TODO Auto-generated method stub
		return fud.querypciture(uid);
	}


}
