package service.impl;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Notice;
import dao.NoticeDao;
import dao.impl.NoticeDaoImpl;
import service.NoticeService;

public class NoticeServiceImpl implements NoticeService {
	
	NoticeDao nd = new NoticeDaoImpl();
	@Override
	public List<Notice> noticelist() {
		// TODO Auto-generated method stub
		return nd.noticelist();
	}
	@Override
	public void usernoticelist(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		try {
			request.getRequestDispatcher("/WEB-INF/admin/noticelist.jsp").forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public List<Notice> querynotices() {
		// TODO Auto-generated method stub
		return nd.querynotices();
	}
	@Override
	public void changenotice(int nid, String ncontent, String nstatus, String nname) {
		// TODO Auto-generated method stub
		nd.changenotice(nid,ncontent,nstatus,nname);
	}
	@Override
	public void insertnotice(Notice notice) {
		// TODO Auto-generated method stub
		notice.setNcontent("默认内容");
		notice.setNstate(1);
		notice.setNname("默认标题");
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String f = sdf.format(date);
		System.out.println(f);
		nd.insertnotice(notice,f);
	}
	@Override
	public void deletenotice(int nid) {
		// TODO Auto-generated method stub
		nd.deletenotice(nid);
	}
	@Override
	public List<Notice> queryablenotice() {
		// TODO Auto-generated method stub
		return nd.queryablenotice();
	}
}
