package service.impl;

import java.util.List;

import bean.Admin;
import bean.AdminRole;
import bean.Role;
import dao.AdminDao;
import dao.impl.AdminDaoImpl;
import service.AdminService;

public class AdminServiceImpl implements AdminService {

	AdminDao ad = new AdminDaoImpl();
	@Override
	public AdminRole login(Admin login) {
		// TODO Auto-generated method stub
		return ad.login(login);
	}
	@Override
	public List<AdminRole> adminlist() {
		// TODO Auto-generated method stub
		return ad.adminlist();
	}
	@Override
	public List<Role> loadadminlist() {
		// TODO Auto-generated method stub
		return ad.loadadminlist();
	}
	@Override
	public void changeaname(int aid,String aname,String apassword, int rid) {
		// TODO Auto-generated method stub
		ad.changeaname(aid,aname,apassword,rid);
	}
	@Override
	public List<AdminRole> querynewadmin() {
		// TODO Auto-generated method stub
		
		return ad.querynewadmin();
	}
	@Override
	public void insertadmin(AdminRole admin) {
		// TODO Auto-generated method stub
		admin.setAname("默认名称");
		admin.setApassword("123");
		admin.setRid(2);
		ad.insertadmin(admin);
	}
	@Override
	public void deleteadmin(int aid) {
		// TODO Auto-generated method stub
		ad.deleteadmin(aid);
	}


}
