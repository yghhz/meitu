package service.impl;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.SmallCategory;
import dao.SmallCategoryDao;
import dao.impl.SmallCategoryDaoImpl;
import service.SmallCategoryService;

public class SmallCategoryServiceImpl implements SmallCategoryService {
	SmallCategoryDao scd = new SmallCategoryDaoImpl();

	@Override
	public List<SmallCategory> querysmallbycid(int cid) {
		// TODO Auto-generated method stub
		return scd.querysmallbycid(cid);
	}

	@Override
	public void smallcategorymanage(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		try {
			request.getRequestDispatcher("/WEB-INF/admin/smallcategorymanage.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void changesmallcate(int sid,String sname) {
		scd.changesmallcate(sid,sname);
	}

	@Override
	public SmallCategory querynewsmallcate(int sid) {
		// TODO Auto-generated method stub
		return scd.querynewsmallcate(sid);
	}

	@Override
	public SmallCategory insertsmallcate(int cid) {
		return scd.insertsmallcate(cid);
	}

	@Override
	public SmallCategory querydefalutsmall(int cid) {
		// TODO Auto-generated method stub
		return scd.querydefalutsmall(cid);
	}

	@Override
	public void deletesmallcate(int sid) {
		// TODO Auto-generated method stub
		scd.deletesmallcate(sid);
	}

	
}
