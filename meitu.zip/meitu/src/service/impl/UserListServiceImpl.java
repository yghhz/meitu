package service.impl;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.PageBean;
import bean.User;
import bean.Ustate;
import dao.UserDao;
import dao.impl.UserListDaoImpl;
import service.UserService;
import utils.BcryptUtil;

public class UserListServiceImpl implements UserService {
	
	UserDao ud = new UserListDaoImpl();
	
	@Override
	public List<User> userlist() {
		// TODO Auto-generated method stub
		return ud.userlist();
	}

	@Override
	public PageBean<User> userlistpage(PageBean<User> pagebean) {
		// TODO Auto-generated method stub
		int total = ud.queryAll();
		pagebean.setTotal(total);
		List<User> datas = ud.querypagelimit(pagebean);
		pagebean.setDatas(datas);
		return pagebean;
	}

	@Override
	public void register(User user) {
		user.setUpassword(BcryptUtil.getBcryptPSW(user.getUpassword()));
		ud.register(user);
	}

	@Override
	public List<User> userlogin(String username, String password) {
		return ud.userlogin(username,password);
	}

	@Override
	public void changeuserinfo(User user) {
		if("女".equals(user.getUsexdisplay())) {
			user.setUsex(1);
		}else if("男".equals(user.getUsexdisplay())) {
			user.setUsex(2);
		}
		
		ud.changeuserinfo(user);
	}

	@Override
	public User flushchangeuserinfo(User user) {
		// TODO Auto-generated method stub
		return ud.flushchangeuserinfo(user);
	}

	@Override
	public void userinfo(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.getRequestDispatcher("/WEB-INF/user/userinfo.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void userclose(User user) {
		// TODO Auto-generated method stub
		ud.userclose(user);
	}

	@Override
	public List<Ustate> queryustate() {
		// TODO Auto-generated method stub
		return ud.queryustate();
	}

	@Override
	public void changeustate(int uid, int ustate) {
		// TODO Auto-generated method stub
		ud.changeustate(uid,ustate);
	}

	@Override
	public User querynewstate(int uid) {
		// TODO Auto-generated method stub
		return ud.querynewstate(uid);
	}

}
