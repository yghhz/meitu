package service.impl;

import java.util.List;

import bean.Picture;
import dao.PictureDao;
import dao.impl.PictureDaoImpl;
import service.PictureService;

public class PictureServiceImpl implements PictureService {
	
	PictureDao ps = new PictureDaoImpl();

	@Override
	public List<Picture> querypictures(String category,String smallcategory, String usernamepicture, String picturedisplay) {
		// TODO Auto-generated method stub
		return ps.querypictures(category,smallcategory,usernamepicture,picturedisplay);
	}

	@Override
	public Picture querysinglepicture(int pid) {
		// TODO Auto-generated method stub
		return ps.querysinglepicture(pid);
	}

	@Override
	public void changepraise(int pid,int praise) {
		// TODO Auto-generated method stub
		ps.changepraise(pid,praise);
	}

	@Override
	public List<Picture> picturerankinglist() {
		// TODO Auto-generated method stub
		return ps.picturerankinglist();
	}


}
