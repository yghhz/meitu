package dao;

import java.util.List;

import bean.Category;

public interface CategoryDao {

	List<Category> queryAll();

	void changecategory(int cid, String cname);

	Category querycategory(int cid);

	void insertcategory(Category insertcate);

	Category querynewcate();

	void deletecategory(int cid);

	void insertdefaultsmallcate(Integer cid);

}
