package dao;

import java.util.List;

import bean.PageBean;
import bean.User;
import bean.Ustate;

public interface UserDao {

	List<User> userlist();

	int queryAll();

	List<User> querypagelimit(PageBean<User> pagebean);

	void register(User user);

	List<User> userlogin(String username, String password);

	void changeuserinfo(User user);

	User flushchangeuserinfo(User user);

	void userclose(User user);

	List<Ustate> queryustate();

	void changeustate(int uid, int ustate);

	User querynewstate(int uid);

	
}
