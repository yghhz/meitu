package dao;

import java.util.List;

import bean.Notice;

public interface NoticeDao {

	List<Notice> noticelist();

	List<Notice> querynotices();

	void changenotice(int nid, String ncontent, String nstatus, String nname);

	void insertnotice(Notice notice, String format);

	void deletenotice(int nid);

	List<Notice> queryablenotice();

}
