package dao;

import java.util.List;

import bean.Admin;
import bean.AdminRole;
import bean.Role;

/**
 * CURD admin表
 * @author wang7
 *
 */
public interface AdminDao {

	AdminRole login(Admin login);

	List<AdminRole> adminlist();

	List<Role> loadadminlist();

	void changeaname(int aid, String aname, String apassword, int rid);

	List<AdminRole> querynewadmin();

	void insertadmin(AdminRole admin);

	void deleteadmin(int aid);

}
