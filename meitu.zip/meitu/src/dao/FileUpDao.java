package dao;

import java.util.List;

import bean.Picture;
import bean.User;

public interface FileUpDao {

	User headportrait(String newFilename, User user);

	int querysid(String smallcategory);

	Picture insertpicture(Picture picture);

	List<Picture> querypciture(Integer uid);

}
