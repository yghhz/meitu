package dao;

public interface FindNameDao {

	boolean finaname(String uname);

}
