package dao;

import java.util.List;

import bean.SmallCategory;


public interface SmallCategoryDao {

	List<SmallCategory> querysmallbycid(int cid);

	void changesmallcate(int sid,String sname);

	SmallCategory querynewsmallcate(int sid);

	SmallCategory insertsmallcate(int cid);

	SmallCategory querydefalutsmall(int cid);

	void deletesmallcate(int sid);

}
