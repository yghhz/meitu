package dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import bean.Picture;
import bean.User;
import dao.FileUpDao;
import utils.PoolUtil;

public class FileUpDaoImpl implements FileUpDao {

	@Override
	public User headportrait(String newFilename, User user) {
		// TODO Auto-generated method stub
		String sql = "UPDATE tuser SET uphoto = ? WHERE uid = ? ";
		String sql2 = "SELECT * FROM tuser WHERE uid = ?";
		Object[] obj2 = {user.getUid()};
		Object[] obj = {newFilename,user.getUid()};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
			User user2 = qr.query(sql2, new BeanHandler<User>(User.class), obj2);
			return user2;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public int querysid(String smallcategory) {
		String sql = "SELECT sid FROM smallcategory WHERE sname = ?";
		Object[] obj = {smallcategory};
		System.out.println(smallcategory);
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			int sid = qr.query(sql, new ScalarHandler<Integer>(), obj);
			return sid;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException();
		}
	}

	@Override
	public Picture insertpicture(Picture picture) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO picture(pname,ppath,sid,uid,pdisplay,praise,psimplyname) VALUES(?,?,?,?,?,?,?)";
		Object[] obj = { picture.getPname(),picture.getPpath(),picture.getSid(),picture.getUid(),picture.getPdisplay(),picture.getPraise(),picture.getPsimplyname()};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
			return picture;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Picture> querypciture(Integer uid) {
		String sql = "SELECT * FROM picture WHERE uid = ?";
		Object[] obj = {uid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<Picture> pictures = qr.query(sql, new BeanListHandler<Picture>(Picture.class), obj);
			return pictures;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

}
