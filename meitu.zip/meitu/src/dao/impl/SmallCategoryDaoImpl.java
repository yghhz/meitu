package dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import bean.SmallCategory;
import dao.SmallCategoryDao;
import utils.PoolUtil;

public class SmallCategoryDaoImpl implements SmallCategoryDao {

	@Override
	public List<SmallCategory> querysmallbycid(int cid) {
		// TODO Auto-generated method stub
		String sql = "select * from smallcategory where cid = ?";
		System.out.println("Dao"+cid);
		Object[] obj = {cid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<SmallCategory> query = qr.query(sql, new BeanListHandler<SmallCategory>(SmallCategory.class), obj);
			System.out.println("dao"+query);
			return query;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void changesmallcate(int sid,String sname) {
		String sql = "UPDATE smallcategory SET sname = ? WHERE sid = ?";
		Object[] obj = {sname,sid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public SmallCategory querynewsmallcate(int sid) {
		String sql = "SELECT * FROM smallcategory WHERE sid = ?";
		Object[] obj = {sid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			SmallCategory query = qr.query(sql, new BeanHandler<SmallCategory>(SmallCategory.class), obj);
			return query;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public SmallCategory insertsmallcate(int cid) {
		String sql = "INSERT INTO smallcategory(sname,cid) VALUES(?,?)";
		Object[] obj = {"默认分类名",cid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			SmallCategory smallCategory = qr.insert(sql, new BeanHandler<SmallCategory>(SmallCategory.class), obj);
			return smallCategory;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public SmallCategory querydefalutsmall(int cid) {
		String sql = "SELECT * FROM smallcategory WHERE cid = ? ORDER BY sid DESC LIMIT 0,1";
		Object[] obj = {cid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			SmallCategory query = qr.query(sql, new BeanHandler<SmallCategory>(SmallCategory.class), obj);
			return query;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
	}

	@Override
	public void deletesmallcate(int sid) {
		// TODO Auto-generated method stub
		String  sql = "DELETE FROM smallcategory WHERE sid = ?";
		Object[] obj = {sid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
