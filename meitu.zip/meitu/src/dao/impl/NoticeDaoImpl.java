package dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import bean.Notice;
import dao.NoticeDao;
import utils.PoolUtil;

public class NoticeDaoImpl implements NoticeDao {

	@Override
	public List<Notice> noticelist() {
		String sql = "SELECT * FROM notice";
		Object[] obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<Notice> notices = qr.query(sql, new BeanListHandler<Notice>(Notice.class), obj);
			return notices;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
	}

	@Override
	public List<Notice> querynotices() {
		String sql = "SELECT * FROM notice";
		Object[] obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<Notice> query = qr.query(sql, new BeanListHandler<Notice>(Notice.class), obj);
			return query;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void changenotice(int nid, String ncontent, String nstatus, String nname) {
		// TODO Auto-generated method stub
		String sql = "UPDATE notice SET ncontent = ?,nstate = ?,nname = ? WHERE nid = ?";
		Object[] obj = {ncontent,nstatus,nname,nid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void insertnotice(Notice notice,String format) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO notice(nname,ncontent,ntime,nstate) VALUES(?,?,?,?)";
		Object[] obj = {notice.getNname(),notice.getNcontent(),format,notice.getNstate()};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.insert(sql, new BeanHandler<Notice>(Notice.class), obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void deletenotice(int nid) {
		// TODO Auto-generated method stub
		String sql = "DELETE FROM notice WHERE nid = ?";
		Object[] obj = {nid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Notice> queryablenotice() {
		// TODO Auto-generated method stub
		String sql ="SELECT * FROM notice WHERE nstate = ?";
		int nstate = 1;
		Object[] obj = {nstate};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<Notice> query = qr.query(sql, new BeanListHandler<Notice>(Notice.class), obj);
			return query;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

}
