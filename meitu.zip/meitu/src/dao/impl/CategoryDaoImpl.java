package dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import bean.Category;
import bean.SmallCategory;
import dao.CategoryDao;
import utils.PoolUtil;

public class CategoryDaoImpl implements CategoryDao {

	@Override
	public List<Category> queryAll() {
		String sql = "select * from category";
		Object[] obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		List<Category> catelist;
		try {
			catelist = qr.query(sql, new BeanListHandler<Category>(Category.class), obj);
			return catelist;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void changecategory(int cid,String cname) {
		String sql = "UPDATE category SET cname = ? WHERE cid = ?";
		Object[] obj = {cname,cid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Category querycategory(int cid) {
		String sql = "SELECT * FROM category WHERE cid = ?";
		Object[] obj = {cid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			Category newcategory = qr.query(sql, new BeanHandler<Category>(Category.class), obj);
			return newcategory;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void insertcategory(Category insertcate) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO category(cname) VALUES(?)";
		Object[] obj = {insertcate.getCname()};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.insert(sql, new BeanHandler<Category>(Category.class), obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public Category querynewcate() {
		String sql = "SELECT * FROM category ORDER BY cid DESC LIMIT 0,1";
		Object[] obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			Category newcate = qr.query(sql, new BeanHandler<Category>(Category.class), obj);
			System.out.println("------"+newcate);
			return newcate;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void deletecategory(int cid) {
		String sql = "DELETE FROM category WHERE cid = ?";
		Object[] obj = {cid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void insertdefaultsmallcate(Integer cid) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO smallcategory(sname,cid) VALUES (?,?)";
		Object[] obj = {"默认分类名",cid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.insert(sql, new BeanHandler<SmallCategory>(SmallCategory.class), obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
