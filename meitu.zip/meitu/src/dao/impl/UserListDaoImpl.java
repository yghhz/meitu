package dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import bean.PageBean;
import bean.User;
import bean.Ustate;
import dao.UserDao;
import utils.PoolUtil;

public class UserListDaoImpl implements UserDao {

	@Override
	public List<User> userlist() {
		
		String sql = "SELECT * FROM tuser";
		Object[] obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<User> users = qr.query(sql, new BeanListHandler<User>(User.class), obj);
			return users;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
	}

	@Override
	public int queryAll() {
		String sql = "select count(uid) as cs from tuser";
		Object[] obj =null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			Number number = qr.query(sql, new ScalarHandler<Number>("cs"), obj);
			return number.intValue();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public List<User> querypagelimit(PageBean<User> pagebean) {
		String sql = "SELECT * FROM tuser limit ?,?";
		Object[] obj = {(pagebean.getNowpage()-1)*pagebean.getPagesize(),pagebean.getPagesize()};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<User> datas = qr.query(sql, new BeanListHandler<User>(User.class), obj);
			return datas;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void register(User user) {
		String sql = "insert into tuser (uname,upassword,unick,usex,ubirthday,uemail) values(?,?,?,?,?,?)";
		Object[] obj = {user.getUname(),user.getUpassword(),user.getUnick(),user.getUsex(),user.getUbirthday(),user.getUemail()};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public List<User> userlogin(String username, String password) {
		String sql = "SELECT * FROM tuser";
		Object[] obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<User> users = qr.query(sql, new BeanListHandler<User>(User.class), obj);
				System.out.println(users.get(0));
				return users;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void changeuserinfo(User user) {
		
		
		String sql = "UPDATE tuser SET unick=?,usex=?,ubirthday=?,uemail=? WHERE uid=? ";
		Object[] obj = {user.getUnick(),user.getUsex(),user.getUbirthday(),user.getUemail(),user.getUid()};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public User flushchangeuserinfo(User user) {
		
		String sql = "SELECT * FROM tuser WHERE uid = ?";
		Object[] obj = {user.getUid()};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			User queryuser = qr.query(sql, new BeanHandler<User>(User.class), obj);
			System.out.println(queryuser);
			return queryuser;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
			
		}
	}

	@Override
	public void userclose(User user) {
		String sql = "UPDATE tuser Set ustate = ? WHERE uid = ?";
		Object[] obj = {2,user.getUid()};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Ustate> queryustate() {
		String sql = "SELECT * FROM ustate";
		Object[] obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<Ustate> query = qr.query(sql, new BeanListHandler<Ustate>(Ustate.class), obj);
			return query;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void changeustate(int uid, int ustate) {
		// TODO Auto-generated method stub
		String sql = "UPDATE tuser SET ustate = ? WHERE uid = ?";
		Object[] obj = {ustate,uid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public User querynewstate(int uid) {
		String sql = "SELECT * FROM tuser WHERE uid = ?";
		Object[] obj = {uid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			User user = qr.query(sql, new BeanHandler<User>(User.class), obj);
			return user;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}


}
