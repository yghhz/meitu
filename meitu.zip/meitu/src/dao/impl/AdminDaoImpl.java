package dao.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import bean.Admin;
import bean.AdminRole;
import bean.Role;
import dao.AdminDao;
import utils.PoolUtil;

public class AdminDaoImpl implements AdminDao {

	@Override
	public AdminRole login(Admin login) {
		String sql = "SELECT a.aid,a.aname,a.apassword,a.rid,r.rname,r.rdisplay "
				+"FROM tadmin a LEFT JOIN role r ON a.rid = r.rid WHERE a.aname = ? AND a.apassword = ?";
		Object[] obj = {login.getAname(),login.getApassword()};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			AdminRole adminRole = qr.query(sql, new BeanHandler<>(AdminRole.class), obj);
			System.out.println("---"+adminRole+"----");
			return adminRole;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public List<AdminRole> adminlist() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM tadmin a LEFT JOIN role b ON a.rid = b.rid";
		Object[] obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<AdminRole> query = qr.query(sql, new BeanListHandler<AdminRole>(AdminRole.class), obj);
			return query;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public List<Role> loadadminlist() {
		String sql = "SELECT * FROM role ";
		Object[] obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<Role> query = qr.query(sql, new BeanListHandler<Role>(Role.class), obj);
			return query;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void changeaname(int aid,String aname,String apassword, int rid) {
		// TODO Auto-generated method stub
		String sql = "UPDATE tadmin SET aname = ?,apassword = ?,rid = ? WHERE aid = ?";
		Object[] obj = {aname,apassword,rid,aid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<AdminRole> querynewadmin() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM tadmin a LEFT JOIN role b ON a.rid = b.rid";
		Object[] obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<AdminRole> query = qr.query(sql, new BeanListHandler<AdminRole>(AdminRole.class), obj);
			return query;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void insertadmin(AdminRole admin) {
		// TODO Auto-generated method stub
		String sql = "INSERT INTO tadmin (aname,apassword,rid) VALUES(?,?,?)";
		Object[] obj = {admin.getAname(),admin.getApassword(),admin.getRid()};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.insert(sql, new BeanHandler<AdminRole>(AdminRole.class), obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void deleteadmin(int aid) {
		// TODO Auto-generated method stub
		String sql = "DELETE FROM tadmin WHERE aid = ?";
		Object[] obj = {aid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
