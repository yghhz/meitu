package dao.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import bean.Picture;
import dao.PictureDao;
import utils.PoolUtil;


public class PictureDaoImpl implements PictureDao {

	@Override
	public List<Picture> querypictures(String category,String smallcategory, String usernamepicture, String picturedisplay) {
		// TODO Auto-generated method stubcategory
		String sql = "SELECT * FROM picture a LEFT JOIN tuser b ON a.uid = b.uid LEFT JOIN smallcategory c ON a.sid = c.sid RIGHT JOIN category d ON c.cid = d.cid WHERE 1 = 1  ";
		Map<String,String> map = new HashMap<>();
		map.put("d.cid", category);
		map.put("c.sid", smallcategory);
		map.put("b.uname", usernamepicture);
		map.put("a.pdisplay", picturedisplay);
		Set<Entry<String, String>> entrySet = map.entrySet();
		for (Entry<String, String> entry : entrySet) {
			String key = entry.getKey();
			String value = entry.getValue();
			if(key!=null) {
				if("d.cid".equals(key) && !"11".equals(value)) {
						sql=sql + " AND "+key+" = "+value;
					
				}else if(("c.sid".equals(key) && !"12".equals(value)) && value != null) {
					sql=sql + " AND "+key+" = "+value;
					
				}else if("d.cid".equals(key) && "11".equals(value)) {
					sql = sql +" AND "+key+" Like "+"'%%'";
					
				}else if(("c.sid".equals(key) && "12".equals(value)) || ("c.sid".equals(key) && value == null) ) {
					sql = sql +" AND "+key+" Like "+"'%%'";
					
				}
				else if("b.uname".equals(key) || "a.pdisplay".equals(key)) {
					sql = sql +" AND "+key+" Like "+"'%"+value+"%'";
				}
				
			}
			System.out.println(sql);
		}
		Object obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<Picture> query = qr.query(sql, new BeanListHandler<Picture>(Picture.class));
			System.out.println("分类查询picture"+query);
			return query;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public Picture querysinglepicture(int pid) {
		String sql = "SELECT * FROM picture WHERE pid = ?";
		Object[] obj = {pid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			Picture picture = qr.query(sql, new BeanHandler<Picture>(Picture.class), obj);
			return picture;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void changepraise(int pid,int praise) {
		String sql = "UPDATE picture SET praise = ? WHERE pid = ?";
		Object[] obj = {praise,pid};
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			qr.update(sql, obj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Picture> picturerankinglist() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM picture ORDER BY praise DESC LIMIT 0,10";
		Object[] obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<Picture> ranklist = qr.query(sql, new BeanListHandler<Picture>(Picture.class), obj);
			return ranklist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		
	}


}
