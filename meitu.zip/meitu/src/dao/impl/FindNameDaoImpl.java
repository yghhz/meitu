package dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import bean.User;
import dao.FindNameDao;
import utils.PoolUtil;

public class FindNameDaoImpl implements FindNameDao {

	@Override
	public boolean finaname(String uname) {
		// TODO Auto-generated method stub
		String sql = "select uname from tuser";
		Object[] obj = null;
		QueryRunner qr = new QueryRunner(PoolUtil.getDataSource());
		try {
			List<User> list = qr.query(sql, new BeanListHandler<User>(User.class), obj);
				for (int i = 0; i < list.size(); i++) {
					User user = list.get(i);
					String str = user.getUname();
					if(str.equals(uname)) {
						return true;
					}
				}
			return false;
			}
			catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
}
