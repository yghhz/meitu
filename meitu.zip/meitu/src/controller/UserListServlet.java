package controller;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bean.PageBean;
import bean.User;
import bean.Ustate;
import service.FindNameService;
import service.UserService;
import service.impl.FindNameServiceImpl;
import service.impl.UserListServiceImpl;

/**
 * Servlet implementation class UserListServlet
 */
@WebServlet("/userlistservlet")
public class UserListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String method = request.getParameter("method");
		if("userlist".equals(method)) {
			this.userlist(request,response);
		}else if("userlistpage".equals(method)) {
			this.userlistpage(request,response);
		}else if("findname".equals(method)) {
			this.findname(request,response);
		}else if("userregister".equals(method)) {
			this.userregister(request,response);
		}else if("userlogin".equals(method)) {
			this.userlogin(request,response);
		}else if("userexit".equals(method)) {
			this.userexit(request,response);
		}else if("changeuserinfo".equals(method)) {
			this.changeuserinfo(request,response);
		}else if("userinfo".equals(method)) {
			this.userinfo(request,response);
		}else if("userclose".equals(method)) {
			this.userclose(request,response);
		}else if("loadstatusdisplay".equals(method)) {
			this.loadstatusdisplay(request,response);
		}else if("changeustate".equals(method)) {
			this.changeustate(request,response);
		}
	}



	private void changeustate(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String uidstr = request.getParameter("uid");
		System.out.println(uidstr);
		int uid = Integer.parseInt(uidstr);
		System.out.println(uid);
		String ustatesstr = request.getParameter("ustate");
		System.out.println(ustatesstr);
		int ustate = Integer.parseInt(ustatesstr);
		System.out.println(ustate);
		UserService us = new UserListServiceImpl();
		us.changeustate(uid,ustate);
		User user = us.querynewstate(uid);
		ObjectMapper om = new ObjectMapper();
		try {
			String jsonstring = om.writeValueAsString(user);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	private void loadstatusdisplay(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		UserService us = new UserListServiceImpl();
		List<Ustate> list = us.queryustate();
		ObjectMapper om = new ObjectMapper();
		try {
			String jsonstring = om.writeValueAsString(list);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	private void userclose(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		ServletContext application = request.getSession().getServletContext();
		application.setAttribute("msg", "用户已注销");
		UserService us = new UserListServiceImpl();
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("User");
		String username = user.getUname();
		String password = user.getUpassword();
		System.out.println(user);
		us.userclose(user);

		session.removeAttribute("User");
		session.invalidate();
		Cookie cookieUserName = new Cookie("username",username);
		Cookie cookieUserPassword = new Cookie("password",password);
		cookieUserName.setMaxAge(0);
		cookieUserPassword.setMaxAge(0);
		response.addCookie(cookieUserPassword);
		response.addCookie(cookieUserName);

		try {
			
//			try {
//				request.getRequestDispatcher("/userlogin.jsp").forward(request, response);
//			} catch (ServletException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			
			response.sendRedirect(request.getContextPath()+"/userlogin.jsp");
			
			return;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}

//			} catch (ServletException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
		}



	private void userinfo(HttpServletRequest request, HttpServletResponse response) {
		UserService us = new UserListServiceImpl();
		us.userinfo(request,response);
		return;
	}



	private void changeuserinfo(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		User user = new User();
		try {
			HttpSession session = request.getSession();
			BeanUtils.populate(user, request.getParameterMap());
			System.out.println(user.getUnick());
			UserService us = new UserListServiceImpl();
			us.changeuserinfo(user);
			User u = us.flushchangeuserinfo(user);
			request.removeAttribute("User");
			session.invalidate();
			request.setAttribute("User", u);
			try {
				request.getRequestDispatcher("/WEB-INF/user/userinfo.jsp").forward(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			};
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	private void userlogin(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		String securityCode = (String) session.getAttribute("securityCode");
		String safecode = request.getParameter("safecode");
		if(!safecode.equalsIgnoreCase(securityCode)) {
			request.setAttribute("msg", "验证码输入错误");
			try {
				request.getRequestDispatcher("/userlogin.jsp").forward(request, response);
				return;
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
		String username = request.getParameter("uname");
		String password = request.getParameter("upassword");
		UserService us = new UserListServiceImpl();
		List<User> users= us.userlogin(username,password);
//		for (User user : users) {
//			if(user.getUname().equals(username) && user.getUpassword().equals(password)) {
//				//这里写登陆后需要显示的内容
//				try {
//					request.getRequestDispatcher("/WEB-INF/user/loginsuccess.jsp").forward(request, response);
//					return;
//				} catch (ServletException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				};
//			}
//		}
		String rememberme = request.getParameter("rememberme");
		if("1".equals(rememberme)) {
			System.out.println("123");
			Cookie cookieUserName = new Cookie("username",username);
			Cookie cookieUserPassword = new Cookie("password",password);
			System.out.println("cookie");
			cookieUserName.setMaxAge(1000*60*60);
			cookieUserPassword.setMaxAge(1000*60*60);
			response.addCookie(cookieUserName);
			response.addCookie(cookieUserPassword);
		}
		for (int i = 0; i < users.size(); i++) {
			
			
			if(users.get(i).getUname().equals(username) && users.get(i).getUpassword().equals(password)) {
				System.out.println(users.get(i).getUname());
				
				System.out.println(users.get(i).getUpassword());
				System.out.println(users.get(i).getUstate());
				if(users.get(i).getUstate()==2) {
					request.setAttribute("msg", "该用户不存在");
					try {
						request.getRequestDispatcher("/userlogin.jsp").forward(request, response);
						return;
					} catch (ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					};
				}
				else if(users.get(i).getUstate()==3) {
					request.setAttribute("msg", "该用户已被冻结");
					try {
						request.getRequestDispatcher("/userlogin.jsp").forward(request, response);
						return;
					} catch (ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					};
				}else {
					try {
						User User = users.get(i);
						String path = "http://localhost:9090/fileupload0709/photo/";
						session.setAttribute("path", path);
						session.setAttribute("User", User);
						request.getRequestDispatcher("/WEB-INF/user/usermain.jsp").forward(request, response);
						return;
					} catch (ServletException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}	
			}
			request.setAttribute("msg", "用户名或密码输入错误");
			try {
				request.getRequestDispatcher("/userlogin.jsp").forward(request, response);
				return;
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			};
		}
		
		
		//密码或用户名错误，转发到登录页面打印错误信息
		
		
	
	private void userexit(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		session.removeAttribute("User");
		session.invalidate();
		try {
			response.sendRedirect(request.getContextPath()+"/userlogin.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void userregister(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		User user = new User();
		try {
			BeanUtils.populate(user, request.getParameterMap());
			System.out.println("123");
			UserService us = new UserListServiceImpl();
			us.register(user);
			request.setAttribute("msg", "注册成功！");
			try {
				request.getRequestDispatcher("/userlogin.jsp").forward(request, response);
				return;
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			};
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void findname(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String uname = request.getParameter("uname");
		FindNameService fns = new FindNameServiceImpl();
		boolean b = fns.finaname(uname);
		if(b) {
			try {
				response.getWriter().write("no");
				return;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			try {
				response.getWriter().write("yes");
				return;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void userlistpage(HttpServletRequest request, HttpServletResponse response) {
		int nowpage = Integer.parseInt(request.getParameter("nowpage"));
		PageBean<User> pagebean = new PageBean<User>();
		pagebean.setNowpage(nowpage);
		pagebean.setPagesize(3);
		UserService us = new UserListServiceImpl();
		PageBean<User> sexypagebean = us.userlistpage(pagebean);
		request.setAttribute("pagebean", sexypagebean);
		try {
			request.getRequestDispatcher("/WEB-INF/admin/userlistpage.jsp").forward(request, response);
			return;
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	protected void userlist(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserService us = new UserListServiceImpl();
		List<User> users = us.userlist();
		request.setAttribute("users", users);
		request.getRequestDispatcher("/WEB-INF/admin/userlist.jsp").forward(request, response);
	}

}
