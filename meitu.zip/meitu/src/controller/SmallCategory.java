package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bean.Category;
import service.CategoryService;
import service.impl.CategoryServiceImpl;

/**
 * Servlet implementation class SmallCategory
 */
@WebServlet("/category")
public class SmallCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		if ("catelist".equals(method)) {
			this.catelist(request,response);
		}else if("categorymanage".equals(method)) {
			this.categorymanage(request,response);
		}else if("changecategory".equals(method)) {
			this.changecategory(request,response);
		}else if("insertcategory".equals(method)) {
			this.insertcategory(request,response);
		}else if("deletecategory".equals(method)) {
			this.deletecategory(request,response);
		}
	}

	private void deletecategory(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String cidstr = request.getParameter("cid");
		int cid = Integer.parseInt(cidstr);
		System.out.println(cid);
		CategoryService cs= new CategoryServiceImpl();
		cs.deletecategory(cid);
		try {
			response.getWriter().write("success");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void insertcategory(HttpServletRequest request, HttpServletResponse response) {
		//首先到数据库新增一条记录
		CategoryService cs = new CategoryServiceImpl();
		Category insertcate = new Category();
		cs.insertcategory(insertcate);
		Category newinsertcate = cs.querynewcate();
		Integer cid = newinsertcate.getCid();
		cs.insertdefaultsmallcate(cid);
		ObjectMapper om = new ObjectMapper();
		try {
			String jsonstring = om.writeValueAsString(newinsertcate);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void changecategory(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		System.out.println("okk");
		CategoryService cs = new CategoryServiceImpl();
		String cidstr = request.getParameter("cid");
		int cid = Integer.parseInt(cidstr);
		String cname = request.getParameter("cname");
		cs.changecategory(cid,cname);
		Category newcategory = cs.querycategory(cid);
		System.out.println(newcategory);
		ObjectMapper om = new ObjectMapper();
		try {
			String jsonstring = om.writeValueAsString(newcategory);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void categorymanage(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		CategoryService cs = new CategoryServiceImpl();
		List<Category> categorys = cs.queryAll();
		System.out.println(categorys);
		HttpSession session = request.getSession();
		session.setAttribute("categorys", categorys);
		cs.categorymanage(request,response);
	}

	private void catelist(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		CategoryService cs = new CategoryServiceImpl();
		List<Category> catelist = cs.queryAll();
		ObjectMapper om = new ObjectMapper();
		String jsonstring = om.writeValueAsString(catelist);
		System.out.println(jsonstring);
		System.out.println("123");
		response.getWriter().write(jsonstring);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
