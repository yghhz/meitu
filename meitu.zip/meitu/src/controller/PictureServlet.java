package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bean.Picture;
import service.PictureService;
import service.impl.PictureServiceImpl;

/**
 * Servlet implementation class PictureServlet
 */
@WebServlet("/pictureservlet")
public class PictureServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	boolean flag = true;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		if("querypictures".equals(method)) {
			this.querypictures(request,response);
		}else if("blurryquerypictures".equals(method)){
			this.blurryquerypictures(request,response);
		}else if("praiseadd".equals(method)) {
			this.praiseadd(request,response);
		}else if("picturerankinglist".equals(method)) {
			this.picturerankinglist(request,response);
		}
	}
	
	private void picturerankinglist(HttpServletRequest request, HttpServletResponse response) {
		PictureService ps = new PictureServiceImpl();
		List<Picture> ranklist = ps.picturerankinglist();
		HttpSession session = request.getSession();
		session.setAttribute("ranklist", ranklist);
		try {
			request.getRequestDispatcher("/WEB-INF/picture/ranklistpicture.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//点赞有点混乱
	private void praiseadd(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String pflag = request.getParameter("pflag");
		if("1".equals(pflag)) {
			
			if(flag) {
		System.out.println("12345");
		String pidstr = request.getParameter("datas");
		System.out.println("pid=="+pidstr);
		int pid = Integer.parseInt(pidstr);	
		HttpSession session = request.getSession();
		PictureService ps = new PictureServiceImpl();
		Picture picture = ps.querysinglepicture(pid);
		System.out.println("picture="+picture);
		int praise = picture.getPraise();
		praise = praise + 1;
		ps.changepraise(pid,praise);
		picture.setPraise(praise);
		ObjectMapper om = new ObjectMapper();
		try {
			String jsonstring = om.writeValueAsString(picture);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		flag = false;
		}
		}else if("2".equals(pflag)){
			if(!flag) {
			System.out.println("12345");
			String pidstr = request.getParameter("datas");
			System.out.println("pid=="+pidstr);
			int pid = Integer.parseInt(pidstr);
			
			HttpSession session = request.getSession();
			PictureService ps = new PictureServiceImpl();
			Picture picture = ps.querysinglepicture(pid);
			System.out.println("picture="+picture);
			int praise = picture.getPraise();
			praise = praise - 1;
			ps.changepraise(pid,praise);
			picture.setPraise(praise);
			ObjectMapper om = new ObjectMapper();
			try {
				String jsonstring = om.writeValueAsString(picture);
				try {
					response.getWriter().write(jsonstring);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
		}
			flag = true;
		}
		
	}

	private void blurryquerypictures(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		PictureService ps = new PictureServiceImpl();
		HttpSession session = request.getSession();
		String category = request.getParameter("category");
		String smallcategory = request.getParameter("smallcategory");
		String usernamepicture = request.getParameter("usernamepicture");
		String picturedisplay = request.getParameter("picturedisplay");
		List<Picture> allpictures = ps.querypictures(category,smallcategory,usernamepicture,picturedisplay);
		session.setAttribute("allpictures",allpictures);
		try {
			request.getRequestDispatcher("/WEB-INF/picture/categorypicture.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void querypictures(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		try {
			request.getRequestDispatcher("/WEB-INF/picture/allpictures.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
