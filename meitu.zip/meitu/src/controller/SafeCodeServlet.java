package controller;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SafeCodeServlet
 */
@WebServlet("/safecodeservlet")
public class SafeCodeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BufferedImage bi = new BufferedImage(120, 40,BufferedImage.TYPE_INT_BGR);
		Graphics2D g = (Graphics2D) bi.getGraphics();
		g.setColor(new Color(0xD3D3D3));
		g.fillRect(0, 0, 120, 40);
		g.setFont(new Font("楷体",Font.BOLD,22));
		char[] cs = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890哈你好帅啊".toCharArray();
		Random r = new Random();
		String securityCode="";
		for(int i = 0; i < 4; i++) {
			String single = cs[r.nextInt(cs.length)]+"";
			securityCode += single;
			g.setColor(new Color(r.nextInt(256),r.nextInt(255),r.nextInt(255)));
			g.drawString(single, i*20, 20);
		}
		HttpSession session = request.getSession();
		//往域里放一个验证码
		session.setAttribute("securityCode", securityCode);
		ImageIO.write(bi, "jpg", response.getOutputStream());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
