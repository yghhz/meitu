package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bean.SmallCategory;
import service.SmallCategoryService;
import service.impl.SmallCategoryServiceImpl;

/**
 * Servlet implementation class SmallCategoryServlet
 */
@WebServlet("/smallcategoryservlet")
public class SmallCategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		if("querysmallbycid".equals(method)) {
			this.querysmallbycid(request,response);
		}else if("smallcategorymanage".equals(method)) {
			this.smallcategorymanage(request,response);
		}else if("changesmallcate".equals(method)) {
			this.changesmallcate(request,response);
		}else if("insertsmallcate".equals(method)) {
			this.insertsmallcate(request,response);
		}else if("deletesmallcate".equals(method)) {
			this.deletesmallcate(request,response);
		}
	}

	private void deletesmallcate(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String sidstr = request.getParameter("sid");
		int sid = Integer.parseInt(sidstr);
		SmallCategoryService scs = new SmallCategoryServiceImpl();
		scs.deletesmallcate(sid);
		try {
			response.getWriter().write("ok");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void insertsmallcate(HttpServletRequest request, HttpServletResponse response) {
		String cidstr = request.getParameter("cid");
		int cid = Integer.parseInt(cidstr);
		System.out.println("smallcate"+cid);
		SmallCategoryService scs = new SmallCategoryServiceImpl();
		scs.insertsmallcate(cid);
		SmallCategory newsmalcate = scs.querydefalutsmall(cid);
		System.out.println(newsmalcate);
		ObjectMapper om = new ObjectMapper();
		try {
			String jsonstring = om.writeValueAsString(newsmalcate);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void changesmallcate(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String cidstr = request.getParameter("cid");
		int cid = Integer.parseInt(cidstr);
		String sidstr = request.getParameter("sid");
		int sid = Integer.parseInt(sidstr);
		String sname = request.getParameter("sname");
		SmallCategoryService scs = new SmallCategoryServiceImpl();
		scs.changesmallcate(sid,sname);
		SmallCategory newsmallcate = scs.querynewsmallcate(sid);
		List<SmallCategory> smc = scs.querysmallbycid(cid);
		System.out.println(smc);
		HttpSession session = request.getSession();
		session.setAttribute("smallcates", smc);
		System.out.println(newsmallcate+"----newsmallcate----");
		ObjectMapper om = new ObjectMapper();
		try {
			String jsonstring = om.writeValueAsString(newsmallcate);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void smallcategorymanage(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		SmallCategoryService scs = new SmallCategoryServiceImpl();
		scs.smallcategorymanage(request,response);
	}

	private void querysmallbycid(HttpServletRequest request, HttpServletResponse response) throws JsonProcessingException {
		// TODO Auto-generated method stub
		String str = request.getParameter("cid");
		int cid = Integer.parseInt(str);
		System.out.println(cid);
		SmallCategoryService scs = new SmallCategoryServiceImpl();
		List<SmallCategory> smc = scs.querysmallbycid(cid);
		System.out.println(smc);
		HttpSession session = request.getSession();
//		session.setAttribute("smallcates", smc);
		ObjectMapper om = new ObjectMapper();
		String jsonstring = om.writeValueAsString(smc);
		try {
			response.getWriter().write(jsonstring);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
