package controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;

import bean.Picture;
import bean.User;
import service.FileUpService;
import service.UserService;
import service.impl.FileUpServiceImpl;
import service.impl.UserListServiceImpl;

/**
 * Servlet implementation class FileUpServlet
 */
@WebServlet("/fileupservlet")
public class FileUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String method = request.getParameter("method");
		if("fileuppage".equals(method)){
			this.fileuppage(request,response);
		}else if("headportrait".equals(method)){
			this.headportrait(request,response);
		}else if("flushphoto".equals(method)) {
			this.flushphoto(request,response);
		}else if("photofileup".equals(method)) {
			this.photofileup(request,response);
		}else if("photofileupconfim".equals(method)){
			this.photofileupconfim(request,response);
		}else if("picturelist".equals(method)) {
			this.picturelist(request,response);
		}
	}




	private void picturelist(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		FileUpService fus = new FileUpServiceImpl();
		//这里将图片的路径和图片名设置到session域中
		//然后jsp进行遍历
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("User");
		Integer uid = user.getUid();
		System.out.println(uid);
		List<Picture> pictures = fus.querypciture(uid);
		System.out.println(pictures.size());
		session.setAttribute("pictures", pictures);
		fus.picturelist(request,response);
	}


	private void photofileupconfim(  HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		Picture picture = new Picture();
//		String smallcategory = request.getParameter("smallcategory");
//		System.out.println(request.getParameter("aaa"));
//		System.out.println(12);
//		System.out.println(smallcategory);
		
//		int sid = fus.querysid(smallcategory);
		FileUpService fus = new FileUpServiceImpl();
		DiskFileItemFactory dfif = new DiskFileItemFactory();
		ServletFileUpload sfu = new ServletFileUpload(dfif);
		String category1 = null,smallcategory1=null,picturedisplay=null;
		int praise=0;
		int sid = 0;
		try {
			List<FileItem> items = sfu.parseRequest(request);
			System.out.println(items.size());
			Iterator<FileItem> i = items.iterator();
			while(i.hasNext()) {
				 FileItem fileItem=(FileItem)i.next();
				 if(!fileItem.isFormField()) {
					 System.out.println("insert");
						String name = fileItem.getName();
						System.out.println(name);
						String pname = UUID.randomUUID().toString().replace("-", "")+name;
						String ppath = "http://localhost:9090/fileupload0709/userpicture/";
						HttpSession session = request.getSession();
						User user = (User) session.getAttribute("User");
						int uid = user.getUid();
						System.out.println(sid);
						Picture newpicture = fus.insertpicture(picture,sid,pname,ppath,uid,picturedisplay,praise,name);
						session.setAttribute("Picture", newpicture);
						System.out.println(newpicture);
						
						Client client = Client.create();
						WebResource webResource = client.resource(ppath+pname);
						try {
							webResource.put(fileItem.getInputStream());
							try {
								request.getRequestDispatcher("/WEB-INF/picture/success.jsp").forward(request, response);
							} catch (ServletException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} catch (UniformInterfaceException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (ClientHandlerException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}else {
						
						try {
							String fieldName = fileItem.getFieldName();//获取表单元素名
							String string = fileItem.getString("UTF-8");
							if("category".equals(fieldName)) {
								category1 = string;
							}else if("smallcategory".equals(fieldName)) {
								smallcategory1 = string;
								System.out.println(smallcategory1);
								sid = Integer.parseInt(smallcategory1);
								
								System.out.println(sid);
							}else if("picturedisplay".equals(fieldName)) {
								picturedisplay = string;
							}
							request.setAttribute("category", category1);
							request.setAttribute("smallcategory", smallcategory1);
							request.setAttribute("picturedisplay", picturedisplay);
							
						} catch (UnsupportedEncodingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						
					}
				
					}
			}
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	private void photofileup(HttpServletRequest request, HttpServletResponse response) {
		FileUpService fus = new FileUpServiceImpl();
		fus.photofileup(request,response);
	}




	private void flushphoto(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String confim = (String)session.getAttribute("confim");
		System.out.println(confim);
		
	}




	private void headportrait(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
		// TODO Auto-generated method stub
		//把托图片存放到图片服务器
		String confim = request.getParameter("confim");
		System.out.println(confim);
		FileUpService fus = new FileUpServiceImpl();
		DiskFileItemFactory dfif = new DiskFileItemFactory();
		ServletFileUpload sfu = new ServletFileUpload(dfif);
		sfu.setHeaderEncoding("UTF-8");
		sfu.setSizeMax(1024L*1024*100);
		try {
			List<FileItem> fms = sfu.parseRequest(request);
			for (FileItem fileItem : fms) {
				if(fileItem.isFormField()) {
					System.out.println(fileItem.getFieldName()+"----"+fileItem.getString("UTF-8"));
				}else{
					String fieldName = fileItem.getName();
					String path = "http://localhost:9090/fileupload0709/photo/";
					String newFilename = UUID.randomUUID().toString().replace("-", "")+fieldName;
					HttpSession session = request.getSession();
					session.setAttribute("confim", confim);
					session.setAttribute("path", path);
					User user = (User) session.getAttribute("User");
					User newuser = new User();
					newuser = fus.headportrait(newFilename,user);
					System.out.println(newuser);
					session.setAttribute("User", newuser);
					
	
					Client client = Client.create();
					WebResource webResource = client.resource(path+newFilename);
					try {
						webResource.put(fileItem.getInputStream());
						try {
							UserService us = new UserListServiceImpl();
							request.getRequestDispatcher("/WEB-INF/user/usermainjump.jsp").forward(request, response);
						} catch (ServletException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
//						response.sendRedirect(request.getContextPath()+"/user/usermain.jsps");
					} catch (UniformInterfaceException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ClientHandlerException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			}
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//将图片名称传入到数据库
	}



	private void fileuppage(HttpServletRequest request, HttpServletResponse response) {
		FileUpService fus = new FileUpServiceImpl();
		fus.fileuppage(request, response);
		
//		User user = (User)request.getSession().getAttribute("User");
//		Object path = request.getSession().getAttribute("path");
//		System.out.println("---------");
//		System.out.println(path);
//		String photo = path+user.getUphoto();
//		try {
//			response.getWriter().write(photo);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
}
