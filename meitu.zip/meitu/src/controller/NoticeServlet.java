package controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bean.Notice;
import service.NoticeService;
import service.impl.NoticeServiceImpl;

/**
 * Servlet implementation class NoticeServlet
 */
@WebServlet("/noticeservlet")
public class NoticeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String method = request.getParameter("method");
		if("noticelist".equals(method)) {
		this.noticelist(request,response);
		}else if("usernoticelist".equals(method)) {
			this.usernoticelist(request,response);
		}else if("noticestatus".equals(method)) {
			this.noticestatus(request,response);
		}else if("changenotice".equals(method)) {
			this.changenotice(request,response);
		}else if("insertnotice".equals(method)) {
			this.insertnotice(request,response);
		}else if("deletenotice".equals(method)) {
			this.deletenotice(request,response);
		}else if("lookupnotice".equals(method)) {
			this.lookupnotice(request,response);
		}
	}

	private void lookupnotice(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		NoticeService ns = new NoticeServiceImpl();
		List<Notice> ablenotices = ns.queryablenotice();
		HttpSession session = request.getSession();
		session.setAttribute("ablenotices", ablenotices);
		try {
			request.getRequestDispatcher("/WEB-INF/notice/usernotice.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void deletenotice(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String nidstr = request.getParameter("nid");
		int nid = Integer.parseInt(nidstr);
		NoticeService ns = new NoticeServiceImpl();
		ns.deletenotice(nid);
		List<Notice> querynotices = ns.querynotices();
		HttpSession session = request.getSession();
		session.setAttribute("notices", querynotices);
		ObjectMapper om = new ObjectMapper();
		
		try {
			String jsonstring = om.writeValueAsString(querynotices);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		

	private void insertnotice(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		NoticeService ns = new NoticeServiceImpl();
		Notice notice = new Notice();
		ns.insertnotice(notice);
		List<Notice> querynotices = ns.querynotices();
		HttpSession session = request.getSession();
		session.setAttribute("notices", querynotices);
		ObjectMapper om = new ObjectMapper();
		
		try {
			String jsonstring = om.writeValueAsString(querynotices);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void changenotice(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		NoticeService ns = new NoticeServiceImpl();
		String nname = request.getParameter("nname");
		String ncontent = request.getParameter("ncontent");
		String nstatus = request.getParameter("nstatus");
		String nidstr = request.getParameter("nid");
		int nid = Integer.parseInt(nidstr);
		ns.changenotice(nid,ncontent,nstatus,nname);
		List<Notice> querynotices = ns.querynotices();
		HttpSession session = request.getSession();
		session.setAttribute("notices", querynotices);
		ObjectMapper om = new ObjectMapper();
		
		try {
			String jsonstring = om.writeValueAsString(querynotices);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void noticestatus(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// TODO Auto-generated method stub
		NoticeService ns = new NoticeServiceImpl();
		List<Notice> notices = ns.querynotices();
		HttpSession session = request.getSession();
		session.setAttribute("notices", notices);
		System.out.println(notices);
		ObjectMapper om = new ObjectMapper();
		try {
			String jsonstring = om.writeValueAsString(notices);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void usernoticelist(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		NoticeService ns = new NoticeServiceImpl();
		ns.usernoticelist(request,response);
	}

	private void noticelist(HttpServletRequest request, HttpServletResponse response) {
		NoticeService ns = new NoticeServiceImpl();
		List<Notice> notices = ns.noticelist();
		request.setAttribute("notices", notices);
		try {
			request.getRequestDispatcher("/WEB-INF/admin/noticelist.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
