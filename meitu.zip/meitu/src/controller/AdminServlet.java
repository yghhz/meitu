package controller;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bean.Admin;
import bean.AdminRole;
import bean.Role;
import service.AdminService;
import service.impl.AdminServiceImpl;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/admin")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String method = request.getParameter("method");
		if("login".equals(method)) {
			this.login(request,response);
		}else if("smallcategorylist".equals(method)) {
			this.smallCategory(request,response);
		}else if("adminlist".equals(method)) {
			this.adminlist(request,response);
		}else if("queryadmin".equals(method)){
			this.queryadmin(request,response);
		}else if("changeaname".equals(method)) {
			this.changeaname(request,response);
		}else if("insertadmin".equals(method)) {
			this.insertadmin(request,response);
		}else if("deleteadmin".equals(method)) {
			this.deleteadmin(request,response);
		}else if("adminexit".equals(method)) {
			this.adminexit(request,response);
		}
	}

	private void adminexit(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		session.removeAttribute("adminrole");
		session.invalidate();
		try {
			response.sendRedirect(request.getContextPath()+"/index.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void deleteadmin(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		AdminService as = new AdminServiceImpl();
		String aidstr = request.getParameter("aid");
		int aid = Integer.parseInt(aidstr);
		as.deleteadmin(aid);
		List<AdminRole> querynewadmin = as.querynewadmin();
		HttpSession session = request.getSession();
		session.setAttribute("admins", querynewadmin);
		ObjectMapper om = new ObjectMapper();
		try {
			String jsonstring = om.writeValueAsString(querynewadmin);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void insertadmin(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		AdminService as = new AdminServiceImpl();
		AdminRole admin = new AdminRole();
		as.insertadmin(admin);
		List<AdminRole> querynewadmin = as.querynewadmin();
		HttpSession session = request.getSession();
		session.setAttribute("admins", querynewadmin);
		ObjectMapper om = new ObjectMapper();
		try {
			String jsonstring = om.writeValueAsString(querynewadmin);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void changeaname(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String aidstr = request.getParameter("aid");
		int aid = Integer.parseInt(aidstr);
		String aname = request.getParameter("aname");
		String apassword = request.getParameter("apassword");
		String ridstr = request.getParameter("rid");
		int rid = Integer.parseInt(ridstr);
		String rdisplay = request.getParameter("rdisplay");
		System.out.println(aid);
		System.out.println(aname);
		System.out.println(apassword);
		AdminService as = new AdminServiceImpl();
		as.changeaname(aid,aname,apassword,rid);
		List<AdminRole> admins = as.querynewadmin();
		HttpSession session = request.getSession();
		session.setAttribute("admins", admins);
		ObjectMapper om = new ObjectMapper();
		try {
			String jsonstring = om.writeValueAsString(admins);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void queryadmin(HttpServletRequest request, HttpServletResponse response) {
		AdminService as = new AdminServiceImpl();
		List<Role> adminlist = as.loadadminlist();
		ObjectMapper om = new ObjectMapper();
		try {
			String jsonstring = om.writeValueAsString(adminlist);
			try {
				response.getWriter().write(jsonstring);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void adminlist(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		AdminService as = new AdminServiceImpl();
		List<AdminRole> admins = as.adminlist();
		System.out.println("+"+admins);
		HttpSession session = request.getSession();
		session.setAttribute("admins", admins);
		try {
			request.getRequestDispatcher("/WEB-INF/admin/adminlist.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void smallCategory(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.getRequestDispatcher("/WEB-INF/admin/smallcategorylist.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Admin login = new Admin();
		try {
			BeanUtils.populate(login, request.getParameterMap());
			AdminService as = new AdminServiceImpl();
			AdminRole adminrole = as.login(login);
			if(adminrole != null) {
				HttpSession session = request.getSession();
				session.setAttribute("adminrole", adminrole);
				request.getRequestDispatcher("/WEB-INF/admin/main.jsp").forward(request, response);;
			}else {
				request.setAttribute("msg", "管理员登陆失败");
				request.getRequestDispatcher("/adminlogin.jsp").forward(request, response);;
			}
			
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
